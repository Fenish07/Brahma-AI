"""Tool registry.

Adding a tool = write one function with the @tool decorator. Nothing else.
"""
from typing import Any, Callable

_REGISTRY: dict[str, dict[str, Any]] = {}


def tool(description: str, properties: dict | None = None, required: list[str] | None = None):
    """Register a function as a tool the LLM can call."""

    def decorator(fn: Callable[..., str]) -> Callable[..., str]:
        _REGISTRY[fn.__name__] = {
            "fn": fn,
            "schema": {
                "name": fn.__name__,
                "description": description,
                "input_schema": {
                    "type": "object",
                    "properties": properties or {},
                    "required": required or [],
                },
            },
        }
        return fn

    return decorator


def get_schemas() -> list[dict]:
    """Tool definitions in the format the Claude API expects."""
    return [t["schema"] for t in _REGISTRY.values()]


def run_tool(name: str, args: dict) -> str:
    """Run a tool by name. Never raises; always returns a short string."""
    entry = _REGISTRY.get(name)
    if entry is None:
        return f"Unknown tool: {name}"
    try:
        return str(entry["fn"](**args))
    except Exception as e:  # tools must not crash the assistant
        return f"Tool '{name}' failed: {e}"


# Import modules at the bottom so their @tool decorators register.
from . import productivity, system, web  # noqa: E402,F401

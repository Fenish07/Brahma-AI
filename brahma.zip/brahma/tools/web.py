"""Browser-related tools."""
import re
import webbrowser
from urllib.parse import urlparse

from . import tool


@tool(
    "Open a website in the default browser.",
    {"url": {"type": "string", "description": "Website address, e.g. youtube.com"}},
    ["url"],
)
def open_website(url: str) -> str:
    url = url.strip()
    if "://" not in url:
        # Reject scheme-like input such as "javascript:..." or "file:..."; allow host:port.
        if re.match(r"^[a-z][a-z0-9+.\-]*:(?!\d+(/|$))", url, re.I):
            return "Refused: only http/https links can be opened."
        url = "https://" + url
    parsed = urlparse(url)
    host = parsed.hostname or ""
    if parsed.scheme not in ("http", "https") or "." not in host and host != "localhost":
        return "Refused: only valid http/https links can be opened."
    webbrowser.open(url)
    return f"Opened {url}"

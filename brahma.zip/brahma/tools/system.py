"""System control tools."""
import platform
import re
import shutil
import subprocess

from . import tool

_SAFE_NAME = re.compile(r"^[\w .\-+]{1,60}$")


@tool(
    "Open an application on the laptop by name, e.g. 'notepad', 'Spotify', 'calculator'.",
    {"name": {"type": "string", "description": "Application name"}},
    ["name"],
)
def open_app(name: str) -> str:
    if not _SAFE_NAME.match(name):
        return "Refused: that app name contains unsafe characters."
    system = platform.system()
    if system == "Windows":
        subprocess.Popen(["cmd", "/c", "start", "", name])
    elif system == "Darwin":
        subprocess.Popen(["open", "-a", name])
    else:
        exe = shutil.which(name.lower()) or shutil.which(name)
        if exe is None:
            return f"Could not find an app called {name}."
        subprocess.Popen([exe])
    return f"Launched {name}"

"""Time, and later: notes and todos."""
import datetime

from . import tool


@tool("Get the current local date and time.")
def get_time() -> str:
    return datetime.datetime.now().strftime("%A, %d %B %Y, %I:%M %p")

# Project: Brahma, a desktop voice assistant (Jarvis-style)

## Stack
- Python 3.11+, virtual environment
- LLM: Anthropic Claude API, model "claude-sonnet-5-5", key from ANTHROPIC_API_KEY via python-dotenv. Never hardcode keys.
- Planned: STT faster-whisper (local), TTS edge-tts with pyttsx3 fallback, wake word "Brahma" via Porcupine custom keyword (fallback: push-to-talk hotkey).

## Structure
main.py, config.py, brain.py, voice/(stt.py, tts.py, wakeword.py), tools/(__init__.py registry, system.py, web.py, productivity.py)

## Rules
- Tool registry: a new tool = one function with the @tool decorator in tools/.
- brain.py runs the tool-use loop until a final text answer; history trimmed without splitting tool_use/tool_result pairs.
- Replies are spoken aloud: concise, natural, no markdown or bullet lists.
- SAFETY: never add a tool that runs arbitrary shell commands. Destructive actions (delete files, close apps, send messages) need user confirmation first. File operations are limited to ALLOWED_FOLDERS in config.py.
- Every tool returns a short string and catches its own exceptions.
- Handle missing microphone, no internet, and API errors without crashing.
- Type hints and short docstrings. Keep code simple.

## Status
- Phase 1 (text brain + get_time, open_website, open_app): done
- Phase 2 (voice: TTS, push-to-talk, wake word): next
- Phase 3 (more tools): pending
- Phase 4 (polish): pending
